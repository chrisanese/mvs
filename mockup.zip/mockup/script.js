// Array Remove - By John Resig (MIT Licensed)
Array.prototype.remove = function (from, to) {
  var rest = this.slice((to || from) + 1 || this.length)
  this.length = from < 0 ? this.length + from : from
  return this.push.apply(this, rest)
}

var Scuttle = {
    "startUrl": "data.json",

    "timeslots": [
        {"abbr": "Mo", "timeslots": ["8", "10", "12", "14", "16", "18"]},
        {"abbr": "Di", "timeslots": ["8", "10", "12", "14", "16", "18"]},
        {"abbr": "Mi", "timeslots": ["8", "10", "12", "14", "16", "18"]},
        {"abbr": "Do", "timeslots": ["8", "10", "12", "14", "16", "18"]},
        {"abbr": "Fr", "timeslots": ["8", "10", "12", "14", "16", "18"]}
    ],

    "templates": new Array(),
    "partials": {},

    "template": function (name, data) {
        return Scuttle.templates[name](data)
    },

    "setup": {},

    "filters": [],

    "findARoom": function () {
        Scuttle.display("find-a-room", {
        })
    },

    "filter": function (slot) {
        var ix = $.inArray(slot, Scuttle.filters)
        if (ix > -1) {
            Scuttle.filters.remove(ix)
        } else {
            Scuttle.filters.push(slot)
        }
        Scuttle.applyFilters()
    },

    "preview": function (obj) {
        var classes = $(obj).attr('class').split(/\s+/)
        $(obj).addClass("hover")
        $(".planing-horizon .slot").removeClass("occupied")
        $(".planing-horizon .slot").addClass("free")
        $.each(classes, function (ix, slot) {
            $(".slot" + slot).addClass("occupied")
        })
    },

    "applyFilters": function () {
        $(".planing-horizon .slot").removeClass("checked free occupied")
        $.each(Scuttle.filters, function (ix, slot) {
            $(".planing-horizon .slot" + slot).addClass("checked")
        })
        $(".room").removeClass("occupied free hover")
        if (Scuttle.filters.length > 0) {
            $(".room").addClass("occupied")
            $.each(Scuttle.filters, function (ix, slot) {
                $(".room:not(." + slot + ")")
                    .removeClass("occupied")
                    .addClass("free")
            })
        }
    },

    "bookARoom": function (bix, fix) {
        if (typeof bix === 'undefined') { bix = 0 }
        if (typeof fix === 'undefined') { fix = 0 }

        Scuttle.display("book-a-room", {
            "building": Scuttle.setup.buildings[bix],
            "buildings": Scuttle.setup.buildings,
            "floor": Scuttle.setup.buildings[bix].floors[fix],
            "floors": Scuttle.setup.buildings[bix].floors,
            "rooms": Scuttle.setup.buildings[bix].floors[fix].rooms,

            "weekdays": Scuttle.timeslots
        })

        $(".button-group .button").removeClass("selected")
        $(".button.room-" + bix).addClass("selected")
        $(".button.floor-" + bix + "-" + fix).addClass("selected")

        Scuttle.applyFilters()
    },

    "load": function (url, onSuccess) {
        $.ajax(url, {
            dataType: "json",
            success: onSuccess,
            error: function(query, textStatus, error) {
                $("#startscreen")
                    .addClass("error")
                    .fadeIn()
                    .html(Scuttle.template("error", {
                        "status": status,
                        "error": error,
                        "url": url
                    }))
            }
        })
    },

    "display": function (template, data) {
        $("#main-frame").html(Scuttle.template(template, data))
    }
}

$(function (doc) {
    $("script[type='template/mustache']").each(function() {
        var rawTemplate = $(this).text()
        var templateName = $(this).attr("name")
        var partial = $(this).attr("partial")
        if (templateName) {
            partial = typeof partial !== 'undefined' && partial !== false
            if (partial) {
                Scuttle.partials[templateName] =
                    Mustache.compilePartial(templateName, rawTemplate)
            } else {
                Scuttle.templates[templateName] =
                    Mustache.compile(rawTemplate)
            }
        }
    })

    Scuttle.load(Scuttle.startUrl, function(data) {

        for (i = 0; i < data.buildings.length; i++) {
            var building = data.buildings[i]
            building["_bix"] = i
            for (j = 0; j < building.floors.length; j++) {
                var floor = building.floors[j]
                floor["_bix"] = i
                floor["_fix"] = j
            }
        }
        Scuttle.setup = data

        $("<div></div>")
            .attr("id", "main-frame")
            .hide()
            .html(Scuttle.template("start", data))
            .appendTo($("body"))
            .fadeIn()
        $("#startscreen")
            .fadeOut()
    })
})

